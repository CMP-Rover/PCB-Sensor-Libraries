# Arduino Footprint Altium
Arduino Uno and Arduino Mega as components in Altium Designer along with footprints.
you can import this library in Altium Designer to use Arduino Uno and Arduino Mega in your projects like a single component as the heart of your project!
